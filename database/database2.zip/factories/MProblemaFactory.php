<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\problema\Mproblema::class, function (Faker $faker) {
    return [
        //
    ];
});
