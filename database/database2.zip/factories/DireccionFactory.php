<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\Direccion::class, function (Faker $faker) {
    return [
        //
    ];
});
