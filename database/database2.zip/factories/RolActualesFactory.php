<?php

use Faker\Generator as Faker;

$factory->define(App\Models\sys\Rol::class, function (Faker $faker) {
    return [
        //
    ];
});
