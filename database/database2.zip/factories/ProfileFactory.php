<?php

use Faker\Generator as Faker;

$factory->define(App\Models\sys\Profile::class, function (Faker $faker) {
    return [
        //
    ];
});
