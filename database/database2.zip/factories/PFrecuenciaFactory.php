<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\producto\PFrecuencia::class, function (Faker $faker) {
    return [
        //
    ];
});
