<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\producto\Pverificador::class, function (Faker $faker) {
    return [
        //
    ];
});
