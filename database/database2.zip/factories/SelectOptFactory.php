<?php

use Faker\Generator as Faker;

$factory->define(App\Models\sys\Setting::class, function (Faker $faker) {
    return [
        //
    ];
});
