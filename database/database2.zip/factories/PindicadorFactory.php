<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\producto\Pindicador::class, function (Faker $faker) {
    return [
        //
    ];
});
