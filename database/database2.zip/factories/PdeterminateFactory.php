<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\problema\Pdeterminante::class, function (Faker $faker) {
    return [
        //
    ];
});
