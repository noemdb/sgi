<?php

use Faker\Generator as Faker;

$factory->define(App\Models\sys\Alert::class, function (Faker $faker) {
    return [
        //
    ];
});
