<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\problema\Pcausaefecto::class, function (Faker $faker) {
    return [
        //
    ];
});
