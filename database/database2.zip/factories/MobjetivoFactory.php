<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\objetivo\Mobjetivo::class, function (Faker $faker) {
    return [
        //
    ];
});
