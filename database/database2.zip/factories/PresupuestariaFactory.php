<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\presupuestaria\Presupuestaria::class, function (Faker $faker) {
    return [
        //
    ];
});
