<?php

use Faker\Generator as Faker;

$factory->define(App\Models\sys\Logdb::class, function (Faker $faker) {
    return [
        //
    ];
});
