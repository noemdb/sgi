<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\actividades\Mactividad::class, function (Faker $faker) {
    return [
        //
    ];
});
