<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\producto\Psupuesto::class, function (Faker $faker) {
    return [
        //
    ];
});
