<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\Responsable::class, function (Faker $faker) {
    return [
        //
    ];
});
