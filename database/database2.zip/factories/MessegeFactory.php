<?php

use Faker\Generator as Faker;

$factory->define(App\Models\sys\Messege::class, function (Faker $faker) {
    return [
        //
    ];
});
