<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\producto\Mproducto::class, function (Faker $faker) {
    return [
        //
    ];
});
