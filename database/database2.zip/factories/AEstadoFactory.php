<?php

use Faker\Generator as Faker;

$factory->define(App\Models\poa\actividades\AEstado::class, function (Faker $faker) {
    return [
        //
    ];
});
