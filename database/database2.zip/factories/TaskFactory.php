<?php

use Faker\Generator as Faker;

$factory->define(App\Models\sys\Task::class, function (Faker $faker) {
    return [
        //
    ];
});
